function [P1 P2] = RevoluteForwardKinematics2D(armLen, theta, origin)
% calculate relative forward kinematics
 

